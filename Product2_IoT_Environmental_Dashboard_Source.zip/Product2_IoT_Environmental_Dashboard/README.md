# Product 2 — IoT Environmental Dashboard (Product No. 23)
Course: 25CAI102PC205 — Cloud Computing

## Product statement
Our product helps users monitor room temperature and humidity using an ESP32/DHT11 sensor, AWS IoT Core, Lambda, S3 and a web dashboard. An OLED displays local readings.

## Architecture
ESP32/DHT11 --MQTT/TLS--> AWS IoT Core --> IoT Rule --> Lambda ingest --> private S3
Browser --> API Gateway --> Lambda latest --> S3
CloudWatch stores Lambda logs. OLED shows local sensor readings.

## Status
This package is prepared, but AWS resources and physical hardware have NOT yet been deployed/tested. The browser starts in clearly labelled simulation mode. Never report simulation as real sensor data.

## Local demo
Open frontend/index.html. To connect AWS later, set API_BASE_URL in frontend/app.js to the API Gateway base URL.

## AWS Learner Lab
Use allowed region (course guide suggests us-east-1/us-west-2; default target us-east-1). Use LabRole where available. Keep S3 private and encrypted. Avoid EC2/NAT/RDS/ECS/EKS for this small project. Monitor budget and clean up resources after faculty permits.

## IoT message
Topic: environment/telemetry
{"device_id":"esp32-room-01","temperature_c":27.4,"humidity_percent":61.0,"timestamp":"2026-11-12T10:00:00Z"}

## Firmware
Install DHT sensor library, Adafruit Unified Sensor, Adafruit GFX, Adafruit SSD1306, PubSubClient and ArduinoJson. Fill placeholders locally with Wi-Fi and IoT certificates. Never share private keys or commit them to public repositories. Common ESP32 pins in this template: DHT data 4, OLED SDA 21, SCL 22; verify your module labels before wiring.
