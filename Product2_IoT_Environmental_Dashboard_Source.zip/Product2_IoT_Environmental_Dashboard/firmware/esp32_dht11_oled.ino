// ESP32 + DHT11 + SSD1306 OLED + AWS IoT Core MQTT/TLS
// Libraries: DHT sensor library, Adafruit Unified Sensor, Adafruit GFX,
// Adafruit SSD1306, PubSubClient, ArduinoJson.
#include <WiFi.h>
#include <WiFiClientSecure.h>
#include <PubSubClient.h>
#include <DHT.h>
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include <ArduinoJson.h>
#define DHTPIN 4
#define DHTTYPE DHT11
#define SDA_PIN 21
#define SCL_PIN 22
DHT dht(DHTPIN,DHTTYPE);
Adafruit_SSD1306 oled(128,64,&Wire,-1);
const char* WIFI_SSID="YOUR_WIFI";
const char* WIFI_PASSWORD="YOUR_PASSWORD";
const char* AWS_ENDPOINT="YOUR_ENDPOINT-ats.iot.us-east-1.amazonaws.com";
const char* TOPIC="environment/telemetry";
// Put downloaded Amazon Root CA, device certificate and private key here locally.
// Never share or commit the private key.
static const char ROOT_CA[] PROGMEM=R"KEY(-----BEGIN CERTIFICATE-----
PASTE_AMAZON_ROOT_CA
-----END CERTIFICATE-----)KEY";
static const char DEVICE_CERT[] PROGMEM=R"KEY(-----BEGIN CERTIFICATE-----
PASTE_DEVICE_CERTIFICATE
-----END CERTIFICATE-----)KEY";
static const char PRIVATE_KEY[] PROGMEM=R"KEY(-----BEGIN RSA PRIVATE KEY-----
PASTE_DEVICE_PRIVATE_KEY
-----END RSA PRIVATE KEY-----)KEY";
WiFiClientSecure net; PubSubClient mqtt(net); unsigned long lastSend=0;
void setup(){Serial.begin(115200);dht.begin();Wire.begin(SDA_PIN,SCL_PIN);oled.begin(SSD1306_SWITCHCAPVCC,0x3C);WiFi.begin(WIFI_SSID,WIFI_PASSWORD);while(WiFi.status()!=WL_CONNECTED)delay(500);net.setCACert(ROOT_CA);net.setCertificate(DEVICE_CERT);net.setPrivateKey(PRIVATE_KEY);mqtt.setServer(AWS_ENDPOINT,8883);}
void loop(){if(!mqtt.connected()){while(!mqtt.connect("esp32-room-01"))delay(1500);}mqtt.loop();if(millis()-lastSend>10000){lastSend=millis();float h=dht.readHumidity(),t=dht.readTemperature();if(isnan(h)||isnan(t)){Serial.println("DHT read failed");return;}StaticJsonDocument<256> d;d["device_id"]="esp32-room-01";d["temperature_c"]=t;d["humidity_percent"]=h;d["timestamp"]=millis();char payload[256];serializeJson(d,payload);bool ok=mqtt.publish(TOPIC,payload);oled.clearDisplay();oled.setTextColor(SSD1306_WHITE);oled.setCursor(0,0);oled.println("EnviroWatch");oled.printf("Temp: %.1f C\n",t);oled.printf("Humidity: %.1f %%\n",h);oled.printf("Cloud: %s",ok?"sent":"retry");oled.display();Serial.println(payload);}}
