# Proposed team role split — confirm actual work
- K. Koushik: product coordination, integration and final demo.
- R. Vignay: AWS architecture and IoT Core setup.
- B. Sirishma: dashboard UI and testing.
- V. Vyshnavi: Lambda/S3 flow and documentation/evidence.
These are proposed assignments, not proof of completed contributions.
