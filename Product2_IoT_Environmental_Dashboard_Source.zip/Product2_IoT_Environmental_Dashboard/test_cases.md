# Test plan
| ID | Test | Expected result | Current status |
|---|---|---|---|
| T01 | Open frontend without API URL | Labelled demo values display | Ready to run |
| T02 | Ingest valid JSON | S3 object stored | Pending AWS |
| T03 | Humidity above 100 | Lambda rejects input | Pending AWS |
| T04 | GET /latest with object present | Latest JSON returned | Pending AWS |
| T05 | GET /latest with empty prefix | 404 response | Pending AWS |
| T06 | ESP32 MQTT publish | IoT rule invokes Lambda | Hardware/cloud pending |
| T07 | OLED | Local values visible | Hardware pending |
| T08 | Lambda execution | CloudWatch log visible | Pending AWS |
