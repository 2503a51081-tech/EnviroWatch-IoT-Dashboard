import json, os, uuid, boto3
from datetime import datetime, timezone
s3=boto3.client("s3")
BUCKET=os.environ["BUCKET_NAME"]
PREFIX=os.environ.get("PREFIX","readings/")
def lambda_handler(event, context):
    if isinstance(event,str): event=json.loads(event)
    if not isinstance(event,dict): raise ValueError("Expected JSON object")
    try: t=float(event["temperature_c"]); h=float(event["humidity_percent"])
    except (KeyError,TypeError,ValueError): raise ValueError("Numeric temperature_c and humidity_percent required")
    if not -40<=t<=80: raise ValueError("Temperature outside accepted range")
    if not 0<=h<=100: raise ValueError("Humidity must be 0..100")
    reading={"device_id":str(event.get("device_id","esp32-room-01")),"temperature_c":t,"humidity_percent":h,"timestamp":str(event.get("timestamp") or datetime.now(timezone.utc).isoformat()),"source":"sensor"}
    key=PREFIX+datetime.now(timezone.utc).strftime("%Y/%m/%d/%H%M%S")+"-"+uuid.uuid4().hex+".json"
    s3.put_object(Bucket=BUCKET,Key=key,Body=json.dumps(reading).encode(),ContentType="application/json",ServerSideEncryption="AES256")
    return {"statusCode":200,"stored_key":key,"reading":reading}
