SELECT *, timestamp() AS received_at FROM 'environment/telemetry'
