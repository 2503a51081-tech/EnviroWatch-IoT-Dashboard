# AWS deployment checklist
1. Start Learner Lab; confirm Active state, permitted region and remaining budget.
2. Create a globally unique private S3 bucket; keep Block Public Access enabled and default encryption on.
3. Create ingest Lambda (Python 3.12), upload lambda_ingest/lambda_function.py, set BUCKET_NAME and PREFIX=readings/. Use permitted LabRole and least-privilege S3 PutObject access.
4. Create latest Lambda from lambda_latest/lambda_function.py with S3 ListBucket/GetObject access for the readings prefix.
5. Create API Gateway HTTP API, GET /latest, integrated with latest Lambda. Configure CORS for the dashboard origin.
6. Create IoT Thing and certificate. Download private key/cert/root CA locally only. Attach an IoT policy limited to Connect and Publish to environment/telemetry.
7. Create IoT Rule for environment/telemetry using aws_iot_rule.sql; action invokes ingest Lambda. Grant invocation permission through the IoT rule wizard.
8. Test ingest Lambda with a sample JSON; confirm an encrypted JSON object appears in S3.
9. Test GET /latest and set API_BASE_URL in frontend/app.js. Host frontend only using a lab-permitted method; alternatively open locally for the demo.
10. Configure ESP32 firmware only when hardware is available; verify actual MQTT delivery and OLED separately.
11. Capture screenshots: S3 private settings/object, Lambda test/log, IoT rule, API response, cloud-backed dashboard, CloudWatch log, physical sensor/OLED only after real test.
12. Clean up resources after evaluation if faculty permits. Do not delete shared LabRole.
