import json, os, boto3
s3=boto3.client("s3"); BUCKET=os.environ["BUCKET_NAME"]; PREFIX=os.environ.get("PREFIX","readings/")
def reply(code,data): return {"statusCode":code,"headers":{"Content-Type":"application/json","Access-Control-Allow-Origin":"*","Cache-Control":"no-store"},"body":json.dumps(data)}
def lambda_handler(event,context):
    try:
        objects=s3.list_objects_v2(Bucket=BUCKET,Prefix=PREFIX).get("Contents",[])
        if not objects: return reply(404,{"message":"No readings stored"})
        latest=max(objects,key=lambda x:x["LastModified"])
        body=s3.get_object(Bucket=BUCKET,Key=latest["Key"])["Body"].read().decode()
        return reply(200,json.loads(body))
    except Exception as e:
        print("Latest reading retrieval failed:",str(e)); return reply(500,{"message":"Unable to retrieve latest reading"})
